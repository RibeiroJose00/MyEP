/*
 * mov_servo.c
 *
 *  Created on: Jan 13, 2025
 *      Author: Ignacio
 */

#include "main.h"
#include "mov_servo.h"

// Función para mover el servo a un ángulo específico
void set_servo_angle(int angle) {
    if (angle < 0) angle = 0;       // Limitar a 0°
    if (angle > 180) angle = 180;   // Limitar a 180°

    int pulse_width = (angle * 1000 / 180) + 1000;  // Convertir ángulo a pulso (1ms - 2ms)
    __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_1, pulse_width);  // Ajustar el duty cycle
}

// Función para abrir el gripper (0° → 180°)
void open_gripper(void) {
    for (int angle = 0; angle <= 180; angle += 5) {  // Aumenta de 5° en 5° suavemente
        set_servo_angle(angle);

        HAL_Delay(20);  // Pequeña pausa para que el servo tenga tiempo de moverse
    }
}

// Función para cerrar el gripper (180° → 0°)
void close_gripper(void) {
    for (int angle = 180; angle >= 0; angle -= 5) {  // Disminuye de 5° en 5° suavemente
        set_servo_angle(angle);
        HAL_Delay(20);
    }
}
