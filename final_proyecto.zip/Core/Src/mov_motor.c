/*
 * mov_motor.c
 *
 *  Created on: Nov 5, 2024
 *      Author: Ignacio
 */

#include "mov_motor.h"
#include "main.h"
#include "stm32f1xx_hal_gpio.h"

//Variables
int ppmm = 10;
int steps_0;
int steps_1;
int target_steps_0;
int target_steps_1;
int dir_0;
int dir_1;
int coords[2] = {10, 10};

_Bool PULSO;
// Parámetros de rampa de velocidad
int initial_ARR = 100;  // Valor de ARR inicial (+bajo = +rapido)
int max_speed_ARR = 1;  // Valor de ARR para la máxima velocidad
int ramp_steps;     // Número de pasos para la rampa de aceleración y desaceleración.

//Homing calibración
void long_homing(){
	homing = 1;

	HAL_TIM_Base_Start_IT(&htim3);

	while(homing && !em_stop);

	coords[0] = -100;
	coords[1] = 100;

	return;
}

//Homing corto
void short_homing(){

	int x_home = -100;
	int y_home = 100;

	set_consign(coords[0], coords[1], x_home, y_home);

	while(moving && !em_stop);

	coords[0] = x_home;
	coords[1] = y_home;

	return;

}

//Movimiento por modo automatico
void auto_move(int x_target, int y_target){

	set_consign(coords[0], coords[1], x_target, y_target);

	while(moving && !em_stop);

	coords[0] = x_target;
	coords[1] = y_target;

	return;
}

//Setear consigna
void set_consign(int x_start, int y_start, int x_end, int y_end){

	//Reiniciamos los pasos
	steps_0 = 0;
	steps_1 = 0;

	//Calculamos la cantidad de pasos y	seteamos la consigna a los motores
	target_steps_0 = (ppmm * abs(x_start - x_end));
	target_steps_1 = (ppmm * abs(y_start - y_end));

	//La rampa es el 1% de la mayor cantidad de pasos a dar
	ramp_steps = (target_steps_0 > target_steps_1) ? (0.01*target_steps_0) : (0.01*target_steps_1);


	//Revisamos la direccion de movimiento
	if(x_start <= x_end){
		HAL_GPIO_WritePin(GPIOB, DIR_0_Pin, GPIO_PIN_RESET);
	}
	else if(x_start >= x_end){
		HAL_GPIO_WritePin(GPIOB, DIR_0_Pin, GPIO_PIN_SET);
	}
	else{
		estado = STATE_ERROR;
	}

	if(y_start <= y_end){
		HAL_GPIO_WritePin(GPIOB, DIR_1_Pin, GPIO_PIN_RESET);
	}
	else if(y_start >= y_end){
		HAL_GPIO_WritePin(GPIOB, DIR_1_Pin, GPIO_PIN_SET);
	}
	else{
		error = 3;
		estado = STATE_ERROR;
	}

	//Empieza a moverse

	moving = 1;

	//Activamos el timer 3

	HAL_TIM_Base_Start_IT(&htim3);



	return;

}


void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim) {

	int new_tim_set_0;
	int new_tim_set_1;
    int final_tim_set;

    if(em_stop){
    	moving = false;
    	HAL_TIM_Base_Stop_IT(&htim3);
    }

    else if(moving){
		if (htim->Instance == TIM3) {
			if(PULSO){
				if (steps_0 < target_steps_0){
					//Pulso al Motor 0
					HAL_GPIO_WritePin(GPIOB, STEP_0_Pin, GPIO_PIN_SET);
					steps_0++;
				}
				if (steps_1 < target_steps_1){
					//Pulso al Motor 1
					HAL_GPIO_WritePin(GPIOB, STEP_1_Pin, GPIO_PIN_SET);
					steps_1++;
				}
					// Ajuste dinámico de ARR para el motor 0 (eje X)
					if (steps_0 <= ramp_steps) {
						new_tim_set_0 = initial_ARR - (steps_0 * (initial_ARR - max_speed_ARR) / ramp_steps);
					} else if (steps_0 >= (target_steps_0 - ramp_steps)) {
						new_tim_set_0 = max_speed_ARR + ((steps_0 - (target_steps_0 - ramp_steps)) * (initial_ARR - max_speed_ARR) / ramp_steps);
					} else {
						new_tim_set_0 = max_speed_ARR;
					}

					// Ajuste dinámico de ARR para el motor 1 (eje Y)
					if (steps_1 <= ramp_steps) {
						new_tim_set_1 = initial_ARR - (steps_1 * (initial_ARR - max_speed_ARR) / ramp_steps);
					} else if (steps_1 >= (target_steps_1 - ramp_steps)) {
						new_tim_set_1 = max_speed_ARR + ((steps_1 - (target_steps_1 - ramp_steps)) * (initial_ARR - max_speed_ARR) / ramp_steps);
					} else {
						new_tim_set_1 = max_speed_ARR;
					}

					 // Aplicar el menor valor de ARR entre ambos motores
					final_tim_set = (new_tim_set_0 > new_tim_set_1) ? new_tim_set_0 : new_tim_set_1;
					__HAL_TIM_SET_AUTORELOAD(&htim3, final_tim_set);


			}

			else{
				//Reset al Motor 0
				HAL_GPIO_WritePin(GPIOB, STEP_0_Pin, GPIO_PIN_RESET);

				//Reset al Motor 1
				HAL_GPIO_WritePin(GPIOB, STEP_1_Pin, GPIO_PIN_RESET);
			}

			PULSO = !PULSO;

			if (steps_0 >= target_steps_0) {
				steps_0 = target_steps_0; // Asegura que no se pase
				//Reset al Motor 0
				HAL_GPIO_WritePin(GPIOB, STEP_0_Pin, GPIO_PIN_RESET);
			}
			if (steps_1 >= target_steps_1) {
				steps_1 = target_steps_1;
				//Reset al Motor 0
				HAL_GPIO_WritePin(GPIOB, STEP_1_Pin, GPIO_PIN_RESET);
			}
		}

		if (steps_0 >= target_steps_0 && steps_1 >= target_steps_1) {
			HAL_TIM_Base_Stop_IT(&htim3);  // **Detiene el timer**
			moving = 0;  // Marca que el movimiento terminó
		}
    }
    else if(homing){
    	int tim_set = 50;
		__HAL_TIM_SET_AUTORELOAD(&htim3, tim_set);
		if(PULSO){
			if(!limit_0){
				//Pulso al Motor 0
				HAL_GPIO_WritePin(GPIOB, STEP_0_Pin, GPIO_PIN_SET);
				steps_0++;
			}
			if(!limit_1){
				//Pulso al Motor 1
				HAL_GPIO_WritePin(GPIOB, STEP_1_Pin, GPIO_PIN_SET);
				steps_1++;
			}
		}else{
			//Reset al Motor 0
			HAL_GPIO_WritePin(GPIOB, STEP_0_Pin, GPIO_PIN_RESET);

			//Reset al Motor 1
			HAL_GPIO_WritePin(GPIOB, STEP_1_Pin, GPIO_PIN_RESET);
		}

		PULSO = !PULSO;
    }
    if (limit_0 && limit_1){
    	HAL_TIM_Base_Stop_IT(&htim3);  // **Detiene el timer**
		homing = 0;  // Marca que el movimiento terminó
	}
}

int get_steps(int motor){
	int steps;
	steps = (motor == 0) ? steps_0 : steps_1;
	return steps;
}

int get_target_steps(int motor){
	int target_steps;
	target_steps = (motor == 0) ? target_steps_0 : target_steps_1;
	return target_steps;
}



