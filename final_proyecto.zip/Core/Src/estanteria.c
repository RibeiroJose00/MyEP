/*
#include "estanteria.h"

//Funcion para crear una estanteria
void create_rack(Rack* rack, uint16_t width, uint16_t height, int num_rows, int num_cols) {
    rack->width = width;
    rack->height = height;
    rack->rows_num = num_rows;
    rack->cols_num = num_cols;
    rack_generate(rack);

}

void rack_generate(Rack* rack) {
    //Generar las casillas
    for (int i = 0; i < rack->rows_num; i++) {
        for (int j = 0; j < rack->cols_num; j++) {
            rack->shelf[i][j].width = rack->width / rack->cols_num;
            rack->shelf[i][j].height = rack->height / rack->rows_num;
            rack->shelf[i][j].center_x = rack->shelf[i][j].width * (0.5 + j);
            rack->shelf[i][j].center_y = rack->shelf[i][j].height * (0.5 + i);
            rack->shelf[i][j].visible = 1;
        }
    }
}

void update_rack_safe(Rack* rack, uint16_t width, uint16_t height, int num_rows, int num_cols) {
    rack_updating = 1; // Indica que la estantería está siendo actualizada

    if (num_rows > MAX_ROWS || num_cols > MAX_COLUMNS) {
        printf("Error: Límites excedidos.\n");
        rack_updating = 0; // Termina la actualización
        return;
    }

    rack->width = width;
    rack->height = height;
    rack->rows_num = num_rows;
    rack->cols_num = num_cols;

    // Regenerar las casillas con los nuevos parámetros
    rack_generate(rack);

    rack_updating = 0; // Finaliza la actualización
}

Shelf get_shelf(const Rack* rack, int row, int column) {
    //Imprimir las casillas

	Shelf shelf_target = rack->shelf[row][column];
    return shelf_target;
}
*/
