/*
 * menu.c
 *
 *  Created on: Dec 5, 2024
 *      Author: Ignacio
 */
#include "menu.h"
#include "usbd_cdc_if.h"
#include "mov_motor.h"
#include "mov_servo.h"

#include <string.h>
#include <stdio.h>

int prev_value;

Shelf target;
int x_target;
int y_target;
int target_row;
int target_col;


// Función para mostrar el menú al cliente USB
void Show_Menu(void) {
    char mensaje[256];
    memset(mensaje,'\0',256);
    switch(estado){
		case STATE_IDLE:
			snprintf(mensaje, sizeof(mensaje),
			"Elija el modo a usar\n"
			"Configurar dimensiones (:S)\n"
			"Modo Automatico (:A)\n");
			break;

		case STATE_SETUP:
			snprintf(mensaje, sizeof(mensaje),
			"Menu de Configuracion:\n"
			"Configurar Alto (:Hx)\n"
			"Configurar Ancho (:Wx)\n"
			"Configurar Filas (:Fx)\n"
			"Configurar Columnas (:Cx)\n"
			"Revisar Parametros (:R)\n"
			"Homing (:H)\n"
			"Volver (:V)\n\n");
			break;

		case STATE_AUTO:
			snprintf(mensaje, sizeof(mensaje),
			"Menu de Movimiento Automatico:\n"
			"Configurar Destino (:Fx Cx)\n"
			"Volver (:V)\n\n");
			break;

/*		case STATE_MANUAL:
			snprintf(mensaje, sizeof(mensaje),
			"Menu de Movimiento Manual:\n"
			"Utiliza la botonera para manejar el equipo\n"
			"Volver (:V)\n\n");
			break;*/
		case STATE_ERROR:
			switch(error){
			case 1:
				snprintf(mensaje, sizeof(mensaje),
				"Revisar finales de carrera\n"
				"Se requiere reiniciar el equipo\n"
				"Errno: %d\n\n", error);
				break;
			case 2:
				snprintf(mensaje, sizeof(mensaje),
				"Error de asignación de memoria\n"
				"Se requiere reiniciar el equipo\n"
				"Errno: %d\n\n", error);
				break;
			case 3:
				snprintf(mensaje, sizeof(mensaje),
				"Llamada de paro de emergencia\n"
				"Puede recuperar el equipo\n"
				"Presione START\n");
				break;
			}
			break;

		case STATE_MOVE:
			snprintf(mensaje, sizeof(mensaje),
			"Presione Enter para continuar\n\n");
			break;
    }


    CDC_Transmit_FS((uint8_t*)mensaje, strlen(mensaje));

}

// Función para procesar la entrada USB y actualizar los valores
void Read_Command(uint8_t* command, uint32_t length) {
	char mensaje[256];
	memset(mensaje,'\0',256);
    switch(estado){

		case STATE_IDLE:

			if (strncmp((const char *)command, ":S", 2) == 0) {
				estado = STATE_SETUP;
			}
			else if(strncmp((const char *)command, ":A", 2) == 0){
				estado = STATE_AUTO;
			}
			//else if(strncmp((const char *)command, ":M", 2) == 0){
			//	estado = STATE_MANUAL;
			//}
			else{

				strcpy(mensaje,"Comando desconocido:\n");
				Send_Message(mensaje);

			}

			break;

		case STATE_SETUP:

			if (strncmp((const char *)command, ":V", 2) == 0){
				update_rack_safe(&rack, width, height, num_rows, num_cols);
				while(rack_updating);
				estado = STATE_IDLE;
			}
			else if(strncmp((const char *)command, ":H", 2) == 0){
				snprintf(mensaje, sizeof(mensaje),
					"Realizando homing\n"
					"Espere a que se detenga el equipo\n\n");
				CDC_Transmit_FS((uint8_t*)mensaje, strlen(mensaje));
				long_homing();

			}

			else if(strncmp((const char *)command, ":R", 2) == 0){
				snprintf(mensaje, sizeof(mensaje),
						"Filas = %u\n"
						"Columnas = %u\n"
						"Alto = %hu\n"
						"Ancho = %hu\n\n"
						,num_rows, num_cols, height, width);
				CDC_Transmit_FS((uint8_t*)mensaje, strlen(mensaje));
			}

			else if(strncmp((const char *)command, ":F", 2) == 0){
				prev_value = num_rows;
				if(sscanf((const char *)command, ":F%2d", &num_rows)!=1){
					num_rows = prev_value;
					strcpy(mensaje, "Ingrese un valor válido\n\n");
					Send_Message(mensaje);
				}

				if(num_rows <= 1){

					num_rows = prev_value;
					strcpy(mensaje, "Las filas deben ser mayor a 1\n"
							"Intente nuevamente\n\n");
					Send_Message(mensaje);
				}
			}

			else if(strncmp((const char *)command, ":C", 2) == 0){
				prev_value = num_cols;
				if (sscanf((const char *)command, ":C%2d", &num_cols)!=1){
					num_cols = prev_value;
					strcpy(mensaje, "Ingrese un valor válido\n\n");
					Send_Message(mensaje);
				}

				if(num_cols <= 1){

					num_cols = prev_value;
					strcpy(mensaje, "Las columnas deben ser mayor a 1\n"
							"Intente nuevamente\n\n");
					Send_Message(mensaje);
				}
			}
			else if(strncmp((const char *)command, ":H", 2) == 0){

				prev_value = height;

				if (sscanf((const char *)command, ":H%4d", &height)!=1){

					height = prev_value;
					strcpy(mensaje, "Ingrese un valor válido\n\n");
					Send_Message(mensaje);
				}

				if(height <= 100){

					height = prev_value;
					strcpy(mensaje, "La altura debe ser mayor a 100mm\n"
							"Intente nuevamente\n\n");
					Send_Message(mensaje);
				}

			}

			else if(strncmp((const char *)command, ":W", 2) == 0){

				prev_value = width;

				if (sscanf((const char *)command, ":W%4d", &width)!=1){

					width = prev_value;
					strcpy(mensaje, "Ingrese un valor válido\n\n");
					Send_Message(mensaje);

				}
				if(width <= 100){

					width = prev_value;
					strcpy(mensaje, "El ancho debe ser mayor a 100mm\n"
							"Intente nuevamente\n\n");
					Send_Message(mensaje);

				}
			}
			else {

				strcpy(mensaje, "Error al analizar el comando:\n\n");
				Send_Message(mensaje);

			}
			break;

		case STATE_AUTO:

			if (strncmp((const char *)command, ":V", 2) == 0){
				estado = STATE_IDLE;
				break;
			}
			else if (sscanf((const char *)command, ":F%2u C%2u", &target_row, &target_col) == 2) {

				snprintf(mensaje, sizeof(mensaje),
						"Fila objetivo: %u\n"
						"Columna objetivo: %u\n\n",
						target_row, target_col);
				CDC_Transmit_FS((uint8_t*)mensaje, strlen(mensaje));
				target_row -= 1;
				target_col -= 1;
				target = get_shelf(&rack, target_row, target_col);

				x_target = target.center_x;
				y_target = target.center_y;

				estado = STATE_MOVE;
				break;

			} else {

				strcpy(mensaje, "Error al analizar el comando:\n"
						"Intente nuevamente\n\n");
				Send_Message(mensaje);
			}
			break;

		//case STATE_MANUAL:
		case STATE_MOVE:

			if(moving == 1){

				strcpy(mensaje,"Espere a que se detenga el equipo:\n\n");
				Send_Message(mensaje);
				break;

			}else{
				set_servo_angle(90);

				strcpy(mensaje,"Moviendo...:\n"
						"Espere a que se detenga el equipo:\n\n");
				Send_Message(mensaje);

				memset(mensaje,'\0',256);

				short_homing();

				open_gripper();

				close_gripper();

				auto_move(x_target, y_target);

				open_gripper();

				close_gripper();

				strcpy(mensaje, "Fin movimiento:\n\n");
				Send_Message(mensaje);

				if(em_stop == false) estado = STATE_AUTO;
				break;
			}

		case STATE_ERROR:


			break;
    }
	//CDC_Transmit_FS((uint8_t*)mensaje, strlen(mensaje));
}

void Send_Message(char* string){
	char mensaje[256];
	snprintf(mensaje, sizeof(mensaje), string);
	CDC_Transmit_FS((uint8_t*)mensaje, strlen(mensaje));
	return;
}

int Get_Steps(int motor){
	return get_steps(motor);
}

int Get_Target_Steps(int motor){
	return get_target_steps(motor);
}


