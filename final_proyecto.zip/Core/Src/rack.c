#include "rack.h"
#include "main.h"

//Funcion para crear una estanteria
void create_rack(Rack* rack, int width, int height, int num_rows, int num_cols) {
    rack->width = width;
    rack->height = height;
    rack->rows_num = num_rows;
    rack->cols_num = num_cols;

    // Asignar memoria para las filas
	rack->shelf = (Shelf**)malloc(num_rows * sizeof(Shelf*));
	if (!rack->shelf) {
		error = 2;
		Error_Handler();
		return;
	}

	// Asignar memoria para cada columna
	for (int i = 0; i < num_rows; i++) {
		rack->shelf[i] = (Shelf*)malloc(num_cols * sizeof(Shelf));
		//Error de memoria
		if (!rack->shelf[i]) {
			error = 2;
			Error_Handler();
			// Liberar memoria previamente asignada
			for (int k = 0; k < i; k++) {
				free(rack->shelf[k]);
			}
			free(rack->shelf);
			return;
		}
	}
    //Generar casillas
    rack_generate(rack);

    return;
}

void rack_generate(Rack* rack) {
    //Generar las casillas
    for (int i = 0; i < rack->rows_num; i++) {
        for (int j = 0; j < rack->cols_num; j++) {
            rack->shelf[i][j].width = rack->width / rack->cols_num;
            rack->shelf[i][j].height = rack->height / rack->rows_num;
            rack->shelf[i][j].center_x = rack->shelf[i][j].width * (0.5 + j);
            rack->shelf[i][j].center_y = rack->shelf[i][j].height * (0.5 + i);
            rack->shelf[i][j].visible = 1;
        }
    }

    return;
}

void update_rack_safe(Rack* rack, int width, int height, int num_rows, int num_cols) {
    rack_updating = 1; // Indica que la estantería está siendo actualizada

    //Limpiamos memoria
    if (rack->shelf) {
		for (int i = 0; i < rack->rows_num; i++) {
			if (rack->shelf[i]) {
				free(rack->shelf[i]);  // Evita liberar memoria no asignada
			}
		}
		free(rack->shelf);
		rack->shelf = NULL;  // Evita uso accidental después de `free()`
	}

    rack->width = width;
    rack->height = height;
    rack->rows_num = num_rows;
    rack->cols_num = num_cols;

    // Asignar nueva memoria
	rack->shelf = (Shelf**)malloc(num_rows * sizeof(Shelf*));
	if (!rack->shelf) {
		rack_updating = 0;
		error = 2;
		Error_Handler();
		return;
	}

	// Asignar memoria para cada fila individualmente
	for (int i = 0; i < num_rows; i++) {
		rack->shelf[i] = (Shelf*)malloc(num_cols * sizeof(Shelf));
		if (!rack->shelf[i]) {
			rack_updating = 0;
			error = 2;
			Error_Handler();
			return;
		}
	}

    // Regenerar las casillas con los nuevos parámetros
    rack_generate(rack);

    rack_updating = 0; // Finaliza la actualización

    return;
}

void free_rack(Rack* rack) {
	//Funcion para limpiar memoria en caso de ser necesario
	if (rack->shelf) {
		for (int i = 0; i < rack->rows_num; i++) {
			if (rack->shelf[i]) {
				free(rack->shelf[i]);  // Evita liberar memoria no asignada
			}
		}
		free(rack->shelf);
		rack->shelf = NULL;  // Evita uso accidental después de `free()`
	}

    return;
}

Shelf get_shelf(const Rack* rack, int row, int column) {
    //Imprimir las casillas

	Shelf shelf_target = rack->shelf[row][column];
    return shelf_target;
}
