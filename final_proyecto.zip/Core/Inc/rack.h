#ifndef RACK_H_
#define RACK_H_

#define MAX_ROWS 20
#define MAX_COLUMNS 20

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>


typedef struct shelf{
    // Atributos de la casilla
    int width;
    int height;
    int center_x;
    int center_y;
    int visible;
} Shelf;

typedef struct rack{
    // Atributos de la estanteria
	int width;
	int height;
    int rows_num;
    int cols_num;
    Shelf** shelf;
} Rack;



void create_rack(Rack* rack, int width, int height, int rows_num, int cols_num);
void rack_generate(Rack* rack);
void update_rack_safe(Rack* rack, int width, int height, int num_rows, int num_cols);
Shelf get_shelf(const Rack* rack, int row, int column);
void free_rack(Rack* rack);

#endif //RACK_H_
