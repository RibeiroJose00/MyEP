/*
 * menu.h
 *
 *  Created on: Dec 5, 2024
 *      Author: Ignacio
 */

#ifndef MENU_H_
#define MENU_H_


#include "main.h"
#include "rack.h"

#include <stdint.h>

extern int target_row;
extern int target_col;
extern int width;
extern int height;
extern int num_rows;
extern int num_cols;

// Declaración de funciones
void Read_Command(uint8_t* data, uint32_t length); // Procesa entrada desde USB
void Show_Menu(void);               // Envia el menú al cliente USB
void Send_Message(char *string);

int Get_Steps(int motor);
int Get_Target_Steps(int motor);


#endif /* MENU_H_ */
