/*#ifndef ESTANTERIA_H
#define ESTANTERIA_H

#define MAX_ROWS 20
#define MAX_COLUMNS 20

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include "main.h"

typedef struct {
    // Atributos de la casilla
    int width;
    int height;
    int center_x;
    int center_y;
    int visible;
} Shelf;

typedef struct {
    // Atributos de la estanteria
    int width;
    int height;
    int rows_num;
    int cols_num;
    Shelf shelf[MAX_ROWS][MAX_COLUMNS];
} Rack;

void create_rack(Rack* rack, uint16_t width, uint16_t height, int rows_num, int cols_num);
Shelf get_shelf(const Rack* rack, int row, int column);
void rack_generate(Rack* rack);

#endif // ESTANTERIA_H
*/
