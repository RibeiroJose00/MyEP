/*
 * mov_motor.h
 *
 *  Created on: Nov 5, 2024
 *      Author: Ignacio
 */

#ifndef MOV_MOTOR_H_
#define MOV_MOTOR_H_

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include "math.h"
#include "stm32f1xx_hal.h"
#include "stm32f103xb.h"

extern int coords[2];
extern int steps_0;
extern int steps_1;
extern int dir_0;
extern int dir_1;
extern int target_steps_0;
extern int target_steps_1;
extern int ppmm;



// Declaración de funciones
void set_consign(int x_start, int y_start, int x_end, int y_end);
void short_homing();
void auto_move(int x_target, int y_target);
void long_homing();

int get_steps(int motor);
int get_target_steps(int motor);

#endif /* MOV_MOTOR_H_ */
