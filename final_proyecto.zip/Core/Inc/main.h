/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f1xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "rack.h"
#include "menu.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

typedef enum State{
    STATE_IDLE,
    STATE_SETUP,
    STATE_AUTO,
	STATE_MOVE,
    STATE_ERROR
} State_t;

extern Rack rack;

extern State_t estado;
extern uint8_t tx_buffer[256];
extern uint8_t rx_buffer[256];


extern volatile _Bool command_ready;
extern volatile _Bool usb_port_open;
extern volatile _Bool rack_updating;
extern volatile _Bool moving;
extern volatile _Bool start;
extern volatile _Bool em_stop;
extern volatile _Bool homing;
extern volatile _Bool limit_0;
extern volatile _Bool limit_1;
extern volatile int error;

extern TIM_HandleTypeDef htim3;
extern TIM_HandleTypeDef htim2;
/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

void HAL_TIM_MspPostInit(TIM_HandleTypeDef *htim);

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define ERR_LED_Pin GPIO_PIN_13
#define ERR_LED_GPIO_Port GPIOC
#define FC_0A_Pin GPIO_PIN_4
#define FC_0A_GPIO_Port GPIOA
#define FC_0A_EXTI_IRQn EXTI4_IRQn
#define FC_0B_Pin GPIO_PIN_5
#define FC_0B_GPIO_Port GPIOA
#define FC_0B_EXTI_IRQn EXTI9_5_IRQn
#define FC_1A_Pin GPIO_PIN_6
#define FC_1A_GPIO_Port GPIOA
#define FC_1A_EXTI_IRQn EXTI9_5_IRQn
#define FC_1B_Pin GPIO_PIN_7
#define FC_1B_GPIO_Port GPIOA
#define FC_1B_EXTI_IRQn EXTI9_5_IRQn
#define START_BTN_Pin GPIO_PIN_10
#define START_BTN_GPIO_Port GPIOB
#define START_BTN_EXTI_IRQn EXTI15_10_IRQn
#define EM_STOP_Pin GPIO_PIN_11
#define EM_STOP_GPIO_Port GPIOB
#define EM_STOP_EXTI_IRQn EXTI15_10_IRQn
#define STEP_0_Pin GPIO_PIN_12
#define STEP_0_GPIO_Port GPIOB
#define DIR_0_Pin GPIO_PIN_13
#define DIR_0_GPIO_Port GPIOB
#define STEP_1_Pin GPIO_PIN_14
#define STEP_1_GPIO_Port GPIOB
#define DIR_1_Pin GPIO_PIN_15
#define DIR_1_GPIO_Port GPIOB

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
