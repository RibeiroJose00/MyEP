/*
 * mov_servo.h
 *
 *  Created on: Jan 13, 2025
 *      Author: Ignacio
 */

#ifndef MOV_SERVO_H_
#define MOV_SERVO_H_

// Funciones para abrir y cerrar el gripper
void set_servo_angle(int angle);
void open_gripper(void);
void close_gripper(void);


#endif /* MOV_SERVO_H_ */
